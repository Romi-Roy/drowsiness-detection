package com.example.carparkingfinder;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ParkingActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private final int LOCATION_PERMISSION_REQUEST_CODE = 1;

    // Parking spot data
    private static final String[] PARKING_NAMES = {
            "1st cross street", "A.M.S. PARKING STAND", "Agastheeswarar Temple Car Parking",
            "AKN Vijayalakshmi Parking Stand", "Amet Private Parking", "Balamurugan Two Wheeler parking",
            "Basement Parking For Students and Staff", "Bike and cycle stand", "Bike Parking",
            "Blueflag Beach Car Park", "Car and Two wheeler parking", "Car Parking",
            "CAR PARKING AREA", "Car Parking-2", "College and Office Buses Parking Lot, Tambaram Corporation",
            "Cresent Parking", "Dev two wheeler stand & parking", "Elite Car Parking - Ramapurm",
            "Ganesh cars", "GRT CAR PARKING", "Hindustan college of arts and science bike parking",
            "Hostel Car Parking", "Jecil Two Wheeler Stand", "Jeyachandran Textiles car and bike Parking",
            "KB CAR PARKING RENT", "Kilambakkam Car and Bike parking", "LLL SAFE CALL DRIVERS",
            "M.R.K Stand", "Marina Beach Car Parking", "MIT Parking Area",
            "Monthly Car Parking (T NAGAR", "MRR Bike Parking", "Multi Level Car Parking",
            "MULTILEVEL CAR PARKING - THE GREATER CHENNAI CORP- MLCP - GCC"
    };

    private static final double[] PARKING_LATITUDES = {
            12.93192357, 12.95171634, 12.88595893, 12.93959561, 12.85773706,
            12.95245713, 12.7980205, 12.91735113, 12.92797784, 12.80234727,
            12.99599171, 12.94169062, 13.02075456, 12.90870257, 12.92024,
            12.8776838, 12.90541569, 13.04056306, 12.92521109, 12.93820071,
            12.7996989, 13.08096869, 12.9514064, 12.92405598, 12.95187038,
            12.87309434, 12.89034672, 12.92498958, 13.04228738, 12.94703788,
            13.03308938, 12.90579772, 12.82822847, 13.04195291
    };

    private static final double[] PARKING_LONGITUDES = {
            80.1332511, 80.14299439, 80.11404482, 80.13139049, 80.23894451,
            80.14064215, 80.21768644, 80.1926703, 80.11798742, 80.24746869,
            80.23098, 80.14577209, 80.19058341, 80.21669706, 80.07390761,
            80.08538368, 80.09449616, 80.18657051, 80.1972735, 80.12494991,
            80.2318524, 80.27317624, 80.14296993, 80.19715663, 80.12423429,
            80.08291036, 80.20530614, 80.11506681, 80.27909517, 80.13903268,
            80.23137331, 80.09478185, 80.22034837, 80.23987055
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parking);

        // Initialize the SupportMapFragment to load the map
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        // Initialize the FusedLocationProviderClient to get the user's location
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Check for location permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            // Permission already granted, fetch the location
            getDeviceLocation();
        } else {
            // Request location permission
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    private void getDeviceLocation() {
        // Check again if the permission is granted
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.getLastLocation()
                    .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            // Got last known location, now update the map with the user's location
                            if (location != null) {
                                LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                                mMap.addMarker(new MarkerOptions().position(userLocation).title("You are here"));
                                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 15));

                                // Find and display the closest parking spots
                                displayClosestParkingSpots(userLocation);
                            } else {
                                Toast.makeText(ParkingActivity.this, "Unable to get your location", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        } else {
            // Permission not granted, show a message
            Toast.makeText(this, "Location permission not granted", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayClosestParkingSpots(LatLng userLocation) {
        List<ParkingSpot> parkingSpots = new ArrayList<>();

        // Calculate distances to each parking spot
        for (int i = 0; i < PARKING_NAMES.length; i++) {
            double distance = haversine(userLocation.latitude, userLocation.longitude, PARKING_LATITUDES[i], PARKING_LONGITUDES[i]);
            parkingSpots.add(new ParkingSpot(PARKING_NAMES[i], new LatLng(PARKING_LATITUDES[i], PARKING_LONGITUDES[i]), distance));
        }

        // Sort parking spots by distance
        parkingSpots.sort(Comparator.comparingDouble(spot -> spot.distance));

        // Display markers for the closest three parking spots
        for (int i = 0; i < Math.min(3, parkingSpots.size()); i++) {
            ParkingSpot spot = parkingSpots.get(i);
            mMap.addMarker(new MarkerOptions().position(spot.latLng).title(spot.name));
        }
    }

    private double haversine(double lat1, double lon1, double lat2, double lon2) {
        final int R = 6371; // Radius of the earth in kilometers
        double latDistance = Math.toRadians(lat2 - lat1);
        double lonDistance = Math.toRadians(lon2 - lon1);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                        Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c; // Distance in kilometers
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission was granted, fetch the location
                getDeviceLocation();
            } else {
                // Permission denied, show a message
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // ParkingSpot class to hold parking data
    private static class ParkingSpot {
        String name;
        LatLng latLng;
        double distance;

        ParkingSpot(String name, LatLng latLng, double distance) {
            this.name = name;
            this.latLng = latLng;
            this.distance = distance;
        }
    }
}
