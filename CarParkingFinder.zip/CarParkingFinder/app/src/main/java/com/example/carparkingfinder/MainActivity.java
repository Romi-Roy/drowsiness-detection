package com.example.carparkingfinder;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Spinner sleepinessSpinner;
    private Button confirmButton;
    private String selectedOption;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find views by their IDs
        sleepinessSpinner = findViewById(R.id.spinner_sleepiness);
        confirmButton = findViewById(R.id.btn_confirm);

        // Handle spinner selection
        sleepinessSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Get the selected option from the spinner
                selectedOption = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Default option when nothing is selected
                selectedOption = null;
            }
        });

        // Handle confirm button click
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedOption != null && selectedOption.equals("Sleepy")) {
                    // Navigate to ParkingActivity
                    Intent intent = new Intent(MainActivity.this, ParkingActivity.class);
                    startActivity(intent);
                } else {
                    // Show a message for other options or if nothing is selected
                    Toast.makeText(MainActivity.this, "Please select 'Sleepy' to proceed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
